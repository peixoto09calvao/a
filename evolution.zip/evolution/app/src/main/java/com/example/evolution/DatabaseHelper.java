package com.example.evolution;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "evolution.db";
    private static final int DATABASE_VERSION = 7; // Incrementado para garantir upgrade

    // Tabelas e colunas
    private static final String TABLE_TREINOS = "treinos";
    private static final String TABLE_USUARIOS = "usuarios";
    private static final String TABLE_EXERCICIOS = "exercicios"; // Corrigido o nome da tabela
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_USUARIO_ID = "usuario_id";
    private static final String COLUMN_NOME = "nome";
    private static final String COLUMN_GRUPO_MUSCULAR = "grupo_muscular"; // Definição da coluna de grupo muscular
    private static final String COLUMN_DIA_SEMANA = "dia_semana";
    private static final String COLUMN_REPETICOES = "repeticoes"; // Coluna de repetições
    private static final String COLUMN_PESO = "peso"; // Coluna de peso
    private static final String COLUMN_DATA = "data"; // Coluna de data
    private static final String COLUMN_DESCRICAO = "descricao"; // Definição da coluna descricao

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Criação da tabela de exercícios
        String createTableExercicios = "CREATE TABLE " + TABLE_EXERCICIOS + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                COLUMN_USUARIO_ID + " INTEGER," +
                COLUMN_NOME + " TEXT," +
                COLUMN_GRUPO_MUSCULAR + " TEXT," +
                COLUMN_DIA_SEMANA + " TEXT," +
                COLUMN_REPETICOES + " INTEGER," +
                COLUMN_PESO + " INTEGER," +
                COLUMN_DATA + " TEXT)";
        db.execSQL(createTableExercicios);

        // Criação da tabela de treinos
        String createTableTreinos = "CREATE TABLE " + TABLE_TREINOS + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                COLUMN_USUARIO_ID + " INTEGER," +
                COLUMN_NOME + " TEXT," +
                COLUMN_DESCRICAO + " TEXT," +
                COLUMN_DIA_SEMANA + " TEXT," +
                COLUMN_REPETICOES + " INTEGER," +
                COLUMN_PESO + " DOUBLE)";
        db.execSQL(createTableTreinos);

        // Criação da tabela de usuários
        String createTableUsuarios = "CREATE TABLE " + TABLE_USUARIOS + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "username TEXT, " +
                "password TEXT)";
        db.execSQL(createTableUsuarios);


    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < newVersion) {
            // Adiciona a coluna 'descricao' se ela não existir
            try {
                db.execSQL("ALTER TABLE " + TABLE_TREINOS + " ADD COLUMN descricao TEXT");
            } catch (SQLException e) {
                // A coluna 'descricao' já pode existir, então ignoramos esse erro
                Log.w("DatabaseUpgrade", "A coluna 'descricao' já existe. Ignorando erro.");
            }

            // Drop e recria tabelas se necessário
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_TREINOS);
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_USUARIOS);
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_EXERCICIOS); // Adicionando a tabela de exercicios
            onCreate(db); // Recria tabelas
        }
    }

    // Métodos relacionados aos usuários
    public void cadastrarUsuario(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("username", username);
        values.put("password", password);
        db.insert(TABLE_USUARIOS, null, values);
        db.close();
    }

    public boolean validarLogin(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USUARIOS, null, "username=? AND password=?",
                new String[]{username, password}, null, null, null);

        boolean isValid = cursor.getCount() > 0;
        cursor.close();
        db.close();
        return isValid;
    }

    public int getUserId(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USUARIOS, new String[]{COLUMN_ID}, "username=?",
                new String[]{username}, null, null, null);

        int userId = -1;
        if (cursor.moveToFirst()) {
            userId = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ID));
        }
        cursor.close();
        db.close();
        return userId;
    }

    // Métodos relacionados aos treinos
    public long salvarTreino(Treino treino) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USUARIO_ID, treino.getUsuarioId());
        values.put(COLUMN_NOME, treino.getNome());
        values.put(COLUMN_DESCRICAO, treino.getDescricao());  // Salvando a descrição
        values.put(COLUMN_DIA_SEMANA, treino.getDiaSemana());

        long id = db.insert(TABLE_TREINOS, null, values);
        db.close();
        return id;
    }

    public List<Treino> buscarTreinosPorUsuario(int usuarioId) {
        List<Treino> treinos = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_TREINOS, null, COLUMN_USUARIO_ID + "=?",
                new String[]{String.valueOf(usuarioId)}, null, null, null);

        if (cursor.moveToFirst()) {
            do {
                Treino treino = new Treino(
                        cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ID)),
                        usuarioId,
                        cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_NOME)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_DESCRICAO)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_DIA_SEMANA))
                );
                treinos.add(treino);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return treinos;
    }

    // Método para atualizar exercício
    public void atualizarExercicio(int usuarioId, String nome, String grupoMuscular, int repeticoes,
                                   int peso, String data) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_NOME, nome);
        values.put(COLUMN_GRUPO_MUSCULAR, grupoMuscular);
        values.put(COLUMN_REPETICOES, repeticoes);
        values.put(COLUMN_PESO, peso);
        values.put(COLUMN_DATA, data);

        // Atualiza o exercício na tabela com base no usuário e nome do exercício
        db.update(TABLE_EXERCICIOS, values, COLUMN_USUARIO_ID + " = ? AND " + COLUMN_NOME + " = ?",
                new String[]{String.valueOf(usuarioId), nome});
        db.close();
    }

    // Método para excluir exercício
    public void excluirExercicio(int usuarioId, String exercicio, String diaSemana) {
        SQLiteDatabase db = this.getWritableDatabase();

        // Deletar exercício da tabela de treinos
        String whereClause = "usuario_id = ? AND exercicio = ? AND dia_semana = ?";
        String[] whereArgs = {String.valueOf(usuarioId), exercicio, diaSemana};

        db.delete(TABLE_TREINOS, whereClause, whereArgs);
        db.close();
    }

    public void salvarExercicio(int usuarioId, String nome, String grupoMuscular, String diaSemana, int repeticiones, int peso, String dataAtual) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues contentValues = new ContentValues();
        contentValues.put(COLUMN_USUARIO_ID, usuarioId);
        contentValues.put(COLUMN_NOME, nome);
        contentValues.put(COLUMN_GRUPO_MUSCULAR, grupoMuscular);
        contentValues.put(COLUMN_DIA_SEMANA, diaSemana);
        contentValues.put(COLUMN_REPETICOES, repeticiones);  // repeticiones como int
        contentValues.put(COLUMN_PESO, peso);  // peso como int
        contentValues.put(COLUMN_DATA, dataAtual);  // data como String

        // Inserir no banco de dados
        db.insert(TABLE_EXERCICIOS, null, contentValues);
        db.close();
    }

    // Método para atualizar treino
    public int atualizarTreino(int treinoId, String nome, String descricao, String diaSemana) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_NOME, nome);
        values.put(COLUMN_DESCRICAO, descricao);  // Atualizando a descrição
        values.put(COLUMN_DIA_SEMANA, diaSemana);

        // Atualiza o treino na tabela com base no ID do treino
        int rowsAffected = db.update(TABLE_TREINOS, values, COLUMN_ID + " = ?",
                new String[]{String.valueOf(treinoId)});
        db.close();

        return rowsAffected; // Retorna o número de linhas afetadas (deve ser 1 se atualizado com sucesso)
    }
    // Método para verificar se o usuário existe no banco de dados
    public boolean usuarioExiste(String username) {
        SQLiteDatabase db = this.getReadableDatabase();

        // Realiza a consulta para verificar se existe um usuário com o nome fornecido
        Cursor cursor = db.query(TABLE_USUARIOS, null, "username=?",
                new String[]{username}, null, null, null);

        boolean existe = cursor.getCount() > 0;  // Se o cursor tiver mais de 0 registros, o usuário existe

        cursor.close();
        db.close();

        return existe; // Retorna true se o usuário existe, false caso contrário
    }

    // Método para buscar exercícios de um usuário por grupo muscular
    public List<String> buscarExerciciosPorGrupo(int usuarioId, String grupoMuscular) {
        List<String> exercicios = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        // Consulta para buscar os exercícios do usuário específico e do grupo muscular especificado
        Cursor cursor = db.query(TABLE_EXERCICIOS, new String[]{COLUMN_NOME, COLUMN_GRUPO_MUSCULAR, COLUMN_REPETICOES, COLUMN_PESO, COLUMN_DIA_SEMANA},
                COLUMN_USUARIO_ID + "=? AND " + COLUMN_GRUPO_MUSCULAR + "=?",
                new String[]{String.valueOf(usuarioId), grupoMuscular}, null, null, null);

        // Verifica se encontrou algum exercício e adiciona na lista
        if (cursor.moveToFirst()) {
            do {
                // Formata o nome do exercício e seus detalhes em uma string
                String nomeExercicio = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_NOME));
                int repeticoes = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_REPETICOES));
                int peso = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_PESO));
                String diaSemana = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_DIA_SEMANA));

                // Adiciona o exercício formatado na lista
                String exercicio = nomeExercicio + " - Reps: " + repeticoes + " - Peso: " + peso + " - Dia: " + diaSemana;
                exercicios.add(exercicio);
            } while (cursor.moveToNext());
        }

        // Fecha o cursor e o banco de dados
        cursor.close();
        db.close();

        return exercicios;  // Retorna a lista de exercícios encontrados
    }
    public List<String> buscarExerciciosPorDia(int usuarioId, String diaSemana) {
        List<String> exercicios = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query("exercicios", new String[]{"nome", "grupoMuscular", "repeticoes", "peso"},
                "usuarioId = ? AND diaSemana = ?",
                new String[]{String.valueOf(usuarioId), diaSemana}, null, null, null);

        if (cursor.moveToFirst()) {
            do {
                String nome = cursor.getString(0);
                String grupo = cursor.getString(1);
                int reps = cursor.getInt(2);
                int peso = cursor.getInt(3);
                exercicios.add(nome + " - " + grupo + " - Reps: " + reps + " - Peso: " + peso);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return exercicios;
    }
    public void salvarExercicio(int usuarioId, String exercicio, String diaSemana) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("usuario_id", usuarioId);
        values.put("exercicio", exercicio);
        values.put("dia_semana", diaSemana);

        db.insert("treinos", null, values);
        db.close();
    }

}
