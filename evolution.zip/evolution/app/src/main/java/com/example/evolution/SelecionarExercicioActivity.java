package com.example.evolution;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class SelecionarExercicioActivity extends Activity {
    private ListView listViewExercicios;
    private DatabaseHelper dbHelper;
    private int treinoId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selecionar_exercicio);

        listViewExercicios = findViewById(R.id.listViewExercicios);
        dbHelper = new DatabaseHelper(this);

        // Obtém o treinoId passado pela Intent
        treinoId = getIntent().getIntExtra("treinoId", -1);

        if (treinoId == -1) {
            Toast.makeText(this, "Erro ao carregar treino.", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Carrega os exercícios para exibir na lista
        carregarExercicios();

        // Evento de clique nos itens da lista
        listViewExercicios.setOnItemClickListener((parent, view, position, id) -> {
            String nomeExercicio = (String) parent.getItemAtPosition(position);
            adicionarExercicioAoTreino(nomeExercicio);
        });
    }

    private void carregarExercicios() {
        ArrayList<String> listaExercicios = new ArrayList<>();
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT nome FROM exercicios", null);

        if (cursor.moveToFirst()) {
            do {
                listaExercicios.add(cursor.getString(cursor.getColumnIndexOrThrow("nome")));
            } while (cursor.moveToNext());
        }
        cursor.close();

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, listaExercicios);
        listViewExercicios.setAdapter(adapter);
    }

    private void adicionarExercicioAoTreino(String nomeExercicio) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        Cursor cursor = db.rawQuery("SELECT id FROM exercicios WHERE nome=?", new String[]{nomeExercicio});
        if (cursor.moveToFirst()) {
            int exercicioId = cursor.getInt(cursor.getColumnIndexOrThrow("id"));

            // Associa o exercício ao treino
            db.execSQL("UPDATE exercicios SET treino_id = ? WHERE id = ?", new Object[]{treinoId, exercicioId});

            Toast.makeText(this, "Exercício adicionado ao treino!", Toast.LENGTH_SHORT).show();
            cursor.close();
            finish(); // Voltar para a tela anterior
        } else {
            Toast.makeText(this, "Erro ao adicionar exercício.", Toast.LENGTH_SHORT).show();
        }
    }
}
