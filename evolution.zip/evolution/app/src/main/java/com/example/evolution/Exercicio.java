package com.example.evolution;

public class Exercicio {
    private int id; // ID do exercício
    private String nome; // Nome do exercício
    private String grupoMuscular; // Grupo muscular associado
    private String diaSemana; // Dia da semana associado
    private String treinoNome; // Nome do treino associado

    // Construtor com todos os parâmetros
    public Exercicio(int id, String nome, String grupoMuscular, String diaSemana, String treinoNome) {
        this.id = id;
        this.nome = nome;
        this.grupoMuscular = grupoMuscular;
        this.diaSemana = diaSemana;
        this.treinoNome = treinoNome;
    }

    // Getters e setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getGrupoMuscular() {
        return grupoMuscular;
    }

    public void setGrupoMuscular(String grupoMuscular) {
        this.grupoMuscular = grupoMuscular;
    }

    public String getDiaSemana() {
        return diaSemana;
    }

    public void setDiaSemana(String diaSemana) {
        this.diaSemana = diaSemana;
    }

    public String getTreinoNome() {
        return treinoNome;
    }

    public void setTreinoNome(String treinoNome) {
        this.treinoNome = treinoNome;
    }

    @Override
    public String toString() {
        return "Exercicio{" +
                "id=" + id +
                ", nome='" + nome + '\'' +
                ", grupoMuscular='" + grupoMuscular + '\'' +
                ", diaSemana='" + diaSemana + '\'' +
                ", treinoNome='" + treinoNome + '\'' +
                '}';
    }
}
