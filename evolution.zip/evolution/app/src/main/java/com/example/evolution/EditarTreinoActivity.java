package com.example.evolution;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class EditarTreinoActivity extends AppCompatActivity {
    private EditText edtNomeTreino, edtDescricaoTreino, edtDiaSemanaTreino;
    private Button btnSalvar, btnCancelar, btnAdicionarExercicio;
    private DatabaseHelper dbHelper;
    private int treinoId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editar_treino);

        // Inicializa os componentes da interface
        edtNomeTreino = findViewById(R.id.edtNomeTreino);
        edtDescricaoTreino = findViewById(R.id.edtDescricaoTreino);
        edtDiaSemanaTreino = findViewById(R.id.edtDiaSemanaTreino);
        btnSalvar = findViewById(R.id.btnSalvarTreino);
        btnCancelar = findViewById(R.id.btnCancelarEdicao);
        btnAdicionarExercicio = findViewById(R.id.btnAdicionarExercicio);

        dbHelper = new DatabaseHelper(this);
        treinoId = getIntent().getIntExtra("treinoId", -1);

        // Carrega os dados do treino e exercícios, se o treino existir
        if (treinoId != -1) {
            carregarDadosTreino(treinoId);
            carregarExercicios(treinoId);
        } else {
            Toast.makeText(this, "Erro ao carregar treino!", Toast.LENGTH_SHORT).show();
            finish();
        }

        // Ação para adicionar um exercício
        btnAdicionarExercicio.setOnClickListener(v -> {
            Intent intent = new Intent(EditarTreinoActivity.this, SelecionarExercicioActivity.class);
            intent.putExtra("treinoId", treinoId);
            startActivity(intent);
        });

        // Ação do botão salvar treino
        btnSalvar.setOnClickListener(v -> {
            String nome = edtNomeTreino.getText().toString().trim();
            String descricao = edtDescricaoTreino.getText().toString().trim();
            String diaSemana = edtDiaSemanaTreino.getText().toString().trim();

            if (nome.isEmpty() || descricao.isEmpty() || diaSemana.isEmpty()) {
                Toast.makeText(this, "Preencha todos os campos!", Toast.LENGTH_SHORT).show();
                return;
            }

            int resultado = dbHelper.atualizarTreino(treinoId, nome, descricao, diaSemana);
            if (resultado > 0) {
                Toast.makeText(this, "Treino atualizado com sucesso!", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(this, "Erro ao atualizar treino.", Toast.LENGTH_SHORT).show();
            }
        });

        btnCancelar.setOnClickListener(v -> finish());
    }

    private void carregarDadosTreino(int id) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.query("treinos", null, "id=?", new String[]{String.valueOf(id)}, null, null, null);

        if (cursor.moveToFirst()) {
            edtNomeTreino.setText(cursor.getString(cursor.getColumnIndexOrThrow("nome")));
            edtDescricaoTreino.setText(cursor.getString(cursor.getColumnIndexOrThrow("descricao")));
            edtDiaSemanaTreino.setText(cursor.getString(cursor.getColumnIndexOrThrow("dia_semana")));
        }
        cursor.close();
    }

    private void carregarExercicios(int treinoId) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT nome, grupo_muscular, carga, peso FROM exercicios WHERE treino_id=?", new String[]{String.valueOf(treinoId)});
        TableLayout tabelaExercicios = findViewById(R.id.tabelaExercicios);

        tabelaExercicios.removeAllViews();
        if (cursor.moveToFirst()) {
            do {
                TableRow row = new TableRow(this);
                TextView nomeExercicio = new TextView(this);
                nomeExercicio.setText(cursor.getString(cursor.getColumnIndexOrThrow("nome")));
                TextView grupoMuscular = new TextView(this);
                grupoMuscular.setText(cursor.getString(cursor.getColumnIndexOrThrow("grupo_muscular")));
                TextView cargaExercicio = new TextView(this);
                cargaExercicio.setText(cursor.getString(cursor.getColumnIndexOrThrow("carga")));
                TextView pesoExercicio = new TextView(this);
                pesoExercicio.setText(cursor.getString(cursor.getColumnIndexOrThrow("peso")));

                // Adicionar campos de edição de carga e peso
                EditText edtCarga = new EditText(this);
                edtCarga.setText(cargaExercicio.getText());
                EditText edtPeso = new EditText(this);
                edtPeso.setText(pesoExercicio.getText());

                // Botão de exclusão
                Button btnExcluir = new Button(this);
                btnExcluir.setText("Excluir");
                btnExcluir.setOnClickListener(v -> excluirExercicio(cursor.getString(cursor.getColumnIndexOrThrow("nome"))));

                row.addView(nomeExercicio);
                row.addView(grupoMuscular);
                row.addView(edtCarga);
                row.addView(edtPeso);
                row.addView(btnExcluir);

                tabelaExercicios.addView(row);
            } while (cursor.moveToNext());
        }
        cursor.close();
    }

    private void excluirExercicio(String nomeExercicio) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.delete("exercicios", "nome=?", new String[]{nomeExercicio});
        Toast.makeText(this, "Exercício excluído com sucesso!", Toast.LENGTH_SHORT).show();
        carregarExercicios(treinoId); // Atualiza a lista de exercícios
    }


}
