package com.example.evolution;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.util.*;

public class TreinoActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private int usuarioId;

    private Spinner grupoMuscularSpinner, diaSemanaSpinner;
    private EditText nomeExercicio, repeticoesExercicio, pesoExercicio;
    private Button btnAdicionarExercicio, btnSalvarTreino;
    private ListView listaExercicios;
    private ArrayAdapter<String> exerciciosAdapter;
    private List<String> exerciciosSelecionados = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_treino);

        dbHelper = new DatabaseHelper(this);

        // Recupera o ID do usuário logado
        Intent intent = getIntent();
        usuarioId = intent.getIntExtra("usuarioId", -1);

        // Referência aos elementos da UI
        grupoMuscularSpinner = findViewById(R.id.grupoMuscularSpinner);
        diaSemanaSpinner = findViewById(R.id.diaSemanaSpinner);
        nomeExercicio = findViewById(R.id.nomeExercicio);
        repeticoesExercicio = findViewById(R.id.repeticoesExercicio);
        pesoExercicio = findViewById(R.id.pesoExercicio);
        btnAdicionarExercicio = findViewById(R.id.btnAdicionarExercicio);
        btnSalvarTreino = findViewById(R.id.btnSalvarTreino);
        listaExercicios = findViewById(R.id.listaExerciciosDisponiveis);

        // Inicializa spinners e lista
        inicializarSpinners();
        configurarLista();

        // Configuração dos botões
        btnAdicionarExercicio.setOnClickListener(view -> adicionarExercicio());
        btnSalvarTreino.setOnClickListener(view -> salvarTreino());
    }

    private void inicializarSpinners() {
        List<String> gruposMusculares = Arrays.asList("Peito", "Costas", "Pernas", "Ombros", "Braços");
        ArrayAdapter<String> grupoAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, gruposMusculares);
        grupoAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        grupoMuscularSpinner.setAdapter(grupoAdapter);

        List<String> diasSemana = Arrays.asList("Segunda-feira", "Terça-feira", "Quarta-feira", "Quinta-feira", "Sexta-feira", "Sábado", "Domingo");
        ArrayAdapter<String> diasAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, diasSemana);
        diasAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        diaSemanaSpinner.setAdapter(diasAdapter);
    }

    private void configurarLista() {
        exerciciosAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, exerciciosSelecionados);
        listaExercicios.setAdapter(exerciciosAdapter);
        listaExercicios.setOnItemClickListener((parent, view, position, id) -> excluirExercicio(position));
    }

    private void adicionarExercicio() {
        String nome = nomeExercicio.getText().toString().trim();
        String repeticoes = repeticoesExercicio.getText().toString().trim();
        String peso = pesoExercicio.getText().toString().trim();

        if (nome.isEmpty() || repeticoes.isEmpty() || peso.isEmpty()) {
            Toast.makeText(this, "Preencha todos os campos", Toast.LENGTH_SHORT).show();
            return;
        }

        String exercicio = nome + " - Reps: " + repeticoes + " - Peso: " + peso + "kg";
        exerciciosSelecionados.add(exercicio);
        exerciciosAdapter.notifyDataSetChanged();
        limparCampos();
    }

    private void limparCampos() {
        nomeExercicio.setText("");
        repeticoesExercicio.setText("");
        pesoExercicio.setText("");
    }

    private void excluirExercicio(int position) {
        exerciciosSelecionados.remove(position);
        exerciciosAdapter.notifyDataSetChanged();
    }

    private void salvarTreino() {
        String diaSemana = diaSemanaSpinner.getSelectedItem().toString();

        for (String exercicio : exerciciosSelecionados) {
            dbHelper.salvarExercicio(usuarioId, exercicio, diaSemana);
        }

        Toast.makeText(this, "Treino salvo com sucesso!", Toast.LENGTH_SHORT).show();
        exerciciosSelecionados.clear();
        exerciciosAdapter.notifyDataSetChanged();
    }
}
