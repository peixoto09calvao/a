package com.example.evolution;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

public class TreinoAdapter extends ArrayAdapter<Treino> {

    private Context context;
    private List<Treino> treinos;

    public TreinoAdapter(Context context, int resource, List<Treino> treinos) {
        super(context, resource, treinos);
        this.context = context;
        this.treinos = treinos;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.treino_item, parent, false);
        }

        Treino treino = treinos.get(position);

        TextView nomeTreino = convertView.findViewById(R.id.nomeTreino);
        TextView descricaoTreino = convertView.findViewById(R.id.descricaoTreino);

        nomeTreino.setText(treino.getNome());
        descricaoTreino.setText(treino.getDescricao());

        return convertView;
    }
}
