package com.example.evolution;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class TreinosSalvosActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private int usuarioId = 1; // Substituir pelo ID do usuário logado
    private ListView listViewTreinos;


    @Override
    protected void onResume() {
        super.onResume();
        carregarTreinos();
    }

    private void carregarTreinos() {
        List<Treino> treinos = dbHelper.buscarTreinosPorUsuario(usuarioId);
        List<String> treinoNomes = new ArrayList<>();
        for (Treino treino : treinos) {
            treinoNomes.add(treino.getNome());
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, treinoNomes);
        listViewTreinos.setAdapter(adapter);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_treinos_salvos);

        dbHelper = new DatabaseHelper(this);
        listViewTreinos = findViewById(R.id.listViewTreinos);

        // Buscar treinos salvos
        List<Treino> treinos = dbHelper.buscarTreinosPorUsuario(usuarioId);
        List<String> treinoNomes = new ArrayList<>();
        for (Treino treino : treinos) {
            treinoNomes.add(treino.getNome());
        }

        // Exibir treinos na ListView
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, treinoNomes);
        listViewTreinos.setAdapter(adapter);

        // Evento de clique para editar ou excluir
        listViewTreinos.setOnItemClickListener((parent, view, position, id) -> {
            String treinoSelecionado = treinoNomes.get(position);
            Toast.makeText(this, "Selecionado: " + treinoSelecionado, Toast.LENGTH_SHORT).show();
            // Implementar ação para editar ou excluir
        });
    }
}

