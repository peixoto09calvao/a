package com.example.evolution;
public class Treino {
    private int id;
    private int usuarioId;
    private String nome;
    private String descricao;
    private String diaSemana;

    public Treino(int id, int usuarioId, String nome, String descricao, String diaSemana) {
        this.id = id;
        this.usuarioId = usuarioId;
        this.nome = nome;
        this.descricao = descricao;
        this.diaSemana = diaSemana;
    }

    // Getters e setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getUsuarioId() { // Getter para usuarioId
        return usuarioId;
    }

    public void setUsuarioId(int usuarioId) {
        this.usuarioId = usuarioId;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getDiaSemana() {
        return diaSemana;
    }

    public void setDiaSemana(String diaSemana) {
        this.diaSemana = diaSemana;
    }

    @Override
    public String toString() {
        return "Treino{" +
                "id=" + id +
                ", usuarioId=" + usuarioId +
                ", nome='" + nome + '\'' +
                ", descricao='" + descricao + '\'' +
                ", diaSemana='" + diaSemana + '\'' +
                '}';
    }
}
