package com.example.evolution;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private Spinner diaSemanaSpinner, grupoMuscularSpinner;
    private EditText nomeExercicio, repeticoesExercicio, pesoExercicio;
    private ListView listaExerciciosDisponiveis;
    private Button btnAdicionarExercicio, btnSalvarTreino;

    private ArrayList<String> exerciciosDisponiveis;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inicializa os elementos da interface
        diaSemanaSpinner = findViewById(R.id.diaSemanaSpinner);
        grupoMuscularSpinner = findViewById(R.id.grupoMuscularSpinner);
        nomeExercicio = findViewById(R.id.nomeExercicio);
        repeticoesExercicio = findViewById(R.id.repeticoesExercicio);
        pesoExercicio = findViewById(R.id.pesoExercicio);
        listaExerciciosDisponiveis = findViewById(R.id.listaExerciciosDisponiveis);
        btnAdicionarExercicio = findViewById(R.id.btnAdicionarExercicio);
        btnSalvarTreino = findViewById(R.id.btnSalvarTreino);

        // Cria a lista de exercícios disponíveis (pode ser obtida de um banco de dados ou outra fonte)
        exerciciosDisponiveis = new ArrayList<>();
        exerciciosDisponiveis.add("Flexão de braço");
        exerciciosDisponiveis.add("Agachamento");
        exerciciosDisponiveis.add("Supino");
        exerciciosDisponiveis.add("Barra fixa");

        // Configura o adapter para a ListView
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, exerciciosDisponiveis);
        listaExerciciosDisponiveis.setAdapter(adapter);

        // Configura o clique do botão "Adicionar exercício"
        btnAdicionarExercicio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nome = nomeExercicio.getText().toString();
                String repeticoes = repeticoesExercicio.getText().toString();
                String peso = pesoExercicio.getText().toString();

                // Adiciona o exercício à lista
                if (!nome.isEmpty() && !repeticoes.isEmpty() && !peso.isEmpty()) {
                    String exercicio = "Exercício: " + nome + ", Repetições: " + repeticoes + ", Peso: " + peso;
                    exerciciosDisponiveis.add(exercicio);

                    // Notifica a ListView sobre a atualização
                    adapter.notifyDataSetChanged();
                } else {
                    Toast.makeText(MainActivity.this, "Preencha todos os campos!", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Configura o clique do botão "Salvar treino"
        btnSalvarTreino.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Aqui você pode adicionar o código para salvar o treino em um banco de dados
                Toast.makeText(MainActivity.this, "Treino salvo com sucesso!", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
