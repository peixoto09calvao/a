package com.example.evolution;

import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;
import com.google.android.material.textfield.TextInputEditText;
import androidx.appcompat.app.AppCompatActivity;

public class CadastroActivity extends AppCompatActivity {
    private TextInputEditText edtUsername, edtPassword, edtConfirmPassword;
    private Button btnCadastrar, btnBackToLogin;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro); // Certifique-se de que o nome do layout está correto

        // Inicialização dos componentes da tela
        edtUsername = findViewById(R.id.edtUsernameCadastro);
        edtPassword = findViewById(R.id.edtPasswordCadastro);
        edtConfirmPassword = findViewById(R.id.edtConfirmPasswordCadastro);
        btnCadastrar = findViewById(R.id.btnCadastrar);
        btnBackToLogin = findViewById(R.id.btnBackToLogin);

        // Inicialização do banco de dados
        dbHelper = new DatabaseHelper(this);

        // Evento de clique do botão de cadastro
        btnCadastrar.setOnClickListener(v -> {
            String username = edtUsername.getText().toString().trim();
            String password = edtPassword.getText().toString().trim();
            String confirmPassword = edtConfirmPassword.getText().toString().trim();

            // Verificando se os campos estão preenchidos
            if (username.isEmpty() || password.isEmpty() || confirmPassword.isEmpty()) {
                Toast.makeText(CadastroActivity.this, "Por favor, preencha todos os campos", Toast.LENGTH_SHORT).show();
                return;
            }

            // Verifica se as senhas coincidem
            if (!password.equals(confirmPassword)) {
                Toast.makeText(CadastroActivity.this, "As senhas não coincidem!", Toast.LENGTH_SHORT).show();
                return;
            }

            // Verificando se o nome de usuário já existe
            if (dbHelper.usuarioExiste(username)) {
                Toast.makeText(CadastroActivity.this, "Nome de usuário já existe!", Toast.LENGTH_SHORT).show();
            } else {
                // Cadastra o novo usuário
                dbHelper.cadastrarUsuario(username, password);
                Toast.makeText(CadastroActivity.this, "Cadastro realizado com sucesso!", Toast.LENGTH_SHORT).show();
                finish(); // Volta para a tela de login
            }
        });

        // Evento de clique do botão de voltar ao login
        btnBackToLogin.setOnClickListener(v -> finish());
    }
}
